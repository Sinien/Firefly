﻿
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BsPatch")]
[assembly: AssemblyDescription("Port of bspatch to .NET; see https://github.com/LogosBible/bsdiff.net.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Logos Bible Software")]
[assembly: AssemblyProduct("BsDiff")]
[assembly: AssemblyCopyright("Copyright 2010 Logos Bible Software")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("4.3.0.0")]
[assembly: AssemblyFileVersion("4.3.0.0")]
