// This file imports lz4.c prefixing all functions with I64_

#include "lz4_64.h"
#include "..\..\..\original\lz4.c"